/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo3_10116075_latihan49_biayaemaskawin;

/**
 *
 * Nama : DESIS FIRMANSYAH
* Kelas : IF3
* NIM   : 10116075
* Deskripsi Program : program ini berisi program untuk menampilkan total bayar 
* dari membeli emas kawin sebagai mahar nikah sesuai harga dan berat yg sudah 
* ditentukan
 */
public class PBO3_10116075_Latihan49_BiayaEmasKawin {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       EmasKawin ek = new EmasKawin();
       ek.setBerat(15.7);
       ek.setHarga(570000);
        System.out.println("LAKLEUY membeli emas kawin untuk mahar dengan berat "
                +ek.getBerat()+" gram");
        System.out.println("1 gram emas per bulan Oktober adalah Rp. "+ek.getHarga());
        System.out.println("Maka, Total bayar yang harus dikeluarkan Hendi adalah Rp. "
        +ek.hitungTotalBayar());
      
    }
    
}
